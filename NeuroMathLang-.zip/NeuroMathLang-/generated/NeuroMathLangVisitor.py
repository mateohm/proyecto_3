# Generated from grammar/NeuroMathLang.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .NeuroMathLangParser import NeuroMathLangParser
else:
    from NeuroMathLangParser import NeuroMathLangParser

# This class defines a complete generic visitor for a parse tree produced by NeuroMathLangParser.

class NeuroMathLangVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by NeuroMathLangParser#program.
    def visitProgram(self, ctx:NeuroMathLangParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#AssignStat.
    def visitAssignStat(self, ctx:NeuroMathLangParser.AssignStatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#ExprStat.
    def visitExprStat(self, ctx:NeuroMathLangParser.ExprStatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#FuncCallStat.
    def visitFuncCallStat(self, ctx:NeuroMathLangParser.FuncCallStatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#ControlStat.
    def visitControlStat(self, ctx:NeuroMathLangParser.ControlStatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#FuncDefStat.
    def visitFuncDefStat(self, ctx:NeuroMathLangParser.FuncDefStatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#assign.
    def visitAssign(self, ctx:NeuroMathLangParser.AssignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#MulDivMod.
    def visitMulDivMod(self, ctx:NeuroMathLangParser.MulDivModContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#Variable.
    def visitVariable(self, ctx:NeuroMathLangParser.VariableContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#Number.
    def visitNumber(self, ctx:NeuroMathLangParser.NumberContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#AddSub.
    def visitAddSub(self, ctx:NeuroMathLangParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#Parens.
    def visitParens(self, ctx:NeuroMathLangParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#UnaryMinus.
    def visitUnaryMinus(self, ctx:NeuroMathLangParser.UnaryMinusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#MatrixExpr.
    def visitMatrixExpr(self, ctx:NeuroMathLangParser.MatrixExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#Compare.
    def visitCompare(self, ctx:NeuroMathLangParser.CompareContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#ListExpr.
    def visitListExpr(self, ctx:NeuroMathLangParser.ListExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#Power.
    def visitPower(self, ctx:NeuroMathLangParser.PowerContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#FuncCallExpr.
    def visitFuncCallExpr(self, ctx:NeuroMathLangParser.FuncCallExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#funcDef.
    def visitFuncDef(self, ctx:NeuroMathLangParser.FuncDefContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#funcCall.
    def visitFuncCall(self, ctx:NeuroMathLangParser.FuncCallContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#IfControl.
    def visitIfControl(self, ctx:NeuroMathLangParser.IfControlContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#WhileControl.
    def visitWhileControl(self, ctx:NeuroMathLangParser.WhileControlContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#ForControl.
    def visitForControl(self, ctx:NeuroMathLangParser.ForControlContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#list.
    def visitList(self, ctx:NeuroMathLangParser.ListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NeuroMathLangParser#matrix.
    def visitMatrix(self, ctx:NeuroMathLangParser.MatrixContext):
        return self.visitChildren(ctx)



del NeuroMathLangParser