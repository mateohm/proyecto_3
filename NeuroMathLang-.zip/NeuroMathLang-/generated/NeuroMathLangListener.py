# Generated from grammar/NeuroMathLang.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .NeuroMathLangParser import NeuroMathLangParser
else:
    from NeuroMathLangParser import NeuroMathLangParser

# This class defines a complete listener for a parse tree produced by NeuroMathLangParser.
class NeuroMathLangListener(ParseTreeListener):

    # Enter a parse tree produced by NeuroMathLangParser#program.
    def enterProgram(self, ctx:NeuroMathLangParser.ProgramContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#program.
    def exitProgram(self, ctx:NeuroMathLangParser.ProgramContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#AssignStat.
    def enterAssignStat(self, ctx:NeuroMathLangParser.AssignStatContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#AssignStat.
    def exitAssignStat(self, ctx:NeuroMathLangParser.AssignStatContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#ExprStat.
    def enterExprStat(self, ctx:NeuroMathLangParser.ExprStatContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#ExprStat.
    def exitExprStat(self, ctx:NeuroMathLangParser.ExprStatContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#FuncCallStat.
    def enterFuncCallStat(self, ctx:NeuroMathLangParser.FuncCallStatContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#FuncCallStat.
    def exitFuncCallStat(self, ctx:NeuroMathLangParser.FuncCallStatContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#ControlStat.
    def enterControlStat(self, ctx:NeuroMathLangParser.ControlStatContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#ControlStat.
    def exitControlStat(self, ctx:NeuroMathLangParser.ControlStatContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#FuncDefStat.
    def enterFuncDefStat(self, ctx:NeuroMathLangParser.FuncDefStatContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#FuncDefStat.
    def exitFuncDefStat(self, ctx:NeuroMathLangParser.FuncDefStatContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#assign.
    def enterAssign(self, ctx:NeuroMathLangParser.AssignContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#assign.
    def exitAssign(self, ctx:NeuroMathLangParser.AssignContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#MulDivMod.
    def enterMulDivMod(self, ctx:NeuroMathLangParser.MulDivModContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#MulDivMod.
    def exitMulDivMod(self, ctx:NeuroMathLangParser.MulDivModContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#Variable.
    def enterVariable(self, ctx:NeuroMathLangParser.VariableContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#Variable.
    def exitVariable(self, ctx:NeuroMathLangParser.VariableContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#Number.
    def enterNumber(self, ctx:NeuroMathLangParser.NumberContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#Number.
    def exitNumber(self, ctx:NeuroMathLangParser.NumberContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#AddSub.
    def enterAddSub(self, ctx:NeuroMathLangParser.AddSubContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#AddSub.
    def exitAddSub(self, ctx:NeuroMathLangParser.AddSubContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#Parens.
    def enterParens(self, ctx:NeuroMathLangParser.ParensContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#Parens.
    def exitParens(self, ctx:NeuroMathLangParser.ParensContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#UnaryMinus.
    def enterUnaryMinus(self, ctx:NeuroMathLangParser.UnaryMinusContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#UnaryMinus.
    def exitUnaryMinus(self, ctx:NeuroMathLangParser.UnaryMinusContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#MatrixExpr.
    def enterMatrixExpr(self, ctx:NeuroMathLangParser.MatrixExprContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#MatrixExpr.
    def exitMatrixExpr(self, ctx:NeuroMathLangParser.MatrixExprContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#Compare.
    def enterCompare(self, ctx:NeuroMathLangParser.CompareContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#Compare.
    def exitCompare(self, ctx:NeuroMathLangParser.CompareContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#ListExpr.
    def enterListExpr(self, ctx:NeuroMathLangParser.ListExprContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#ListExpr.
    def exitListExpr(self, ctx:NeuroMathLangParser.ListExprContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#Power.
    def enterPower(self, ctx:NeuroMathLangParser.PowerContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#Power.
    def exitPower(self, ctx:NeuroMathLangParser.PowerContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#FuncCallExpr.
    def enterFuncCallExpr(self, ctx:NeuroMathLangParser.FuncCallExprContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#FuncCallExpr.
    def exitFuncCallExpr(self, ctx:NeuroMathLangParser.FuncCallExprContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#funcDef.
    def enterFuncDef(self, ctx:NeuroMathLangParser.FuncDefContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#funcDef.
    def exitFuncDef(self, ctx:NeuroMathLangParser.FuncDefContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#funcCall.
    def enterFuncCall(self, ctx:NeuroMathLangParser.FuncCallContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#funcCall.
    def exitFuncCall(self, ctx:NeuroMathLangParser.FuncCallContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#IfControl.
    def enterIfControl(self, ctx:NeuroMathLangParser.IfControlContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#IfControl.
    def exitIfControl(self, ctx:NeuroMathLangParser.IfControlContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#WhileControl.
    def enterWhileControl(self, ctx:NeuroMathLangParser.WhileControlContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#WhileControl.
    def exitWhileControl(self, ctx:NeuroMathLangParser.WhileControlContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#ForControl.
    def enterForControl(self, ctx:NeuroMathLangParser.ForControlContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#ForControl.
    def exitForControl(self, ctx:NeuroMathLangParser.ForControlContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#list.
    def enterList(self, ctx:NeuroMathLangParser.ListContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#list.
    def exitList(self, ctx:NeuroMathLangParser.ListContext):
        pass


    # Enter a parse tree produced by NeuroMathLangParser#matrix.
    def enterMatrix(self, ctx:NeuroMathLangParser.MatrixContext):
        pass

    # Exit a parse tree produced by NeuroMathLangParser#matrix.
    def exitMatrix(self, ctx:NeuroMathLangParser.MatrixContext):
        pass



del NeuroMathLangParser