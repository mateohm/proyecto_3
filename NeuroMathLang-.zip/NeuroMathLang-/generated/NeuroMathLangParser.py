# Generated from grammar/NeuroMathLang.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,29,182,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,1,0,5,0,20,8,0,10,0,12,0,23,9,0,1,0,1,0,1,1,1,
        1,3,1,29,8,1,1,1,1,1,3,1,33,8,1,1,1,1,1,3,1,37,8,1,1,1,1,1,3,1,41,
        8,1,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        1,3,3,3,59,8,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,5,
        3,73,8,3,10,3,12,3,76,9,3,1,4,1,4,1,4,1,4,1,4,1,4,5,4,84,8,4,10,
        4,12,4,87,9,4,3,4,89,8,4,1,4,1,4,1,4,5,4,94,8,4,10,4,12,4,97,9,4,
        1,4,1,4,1,5,1,5,1,5,1,5,1,5,5,5,106,8,5,10,5,12,5,109,9,5,3,5,111,
        8,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,5,6,121,8,6,10,6,12,6,124,9,
        6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,134,8,6,10,6,12,6,137,9,6,
        1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,151,8,6,10,6,
        12,6,154,9,6,1,6,1,6,3,6,158,8,6,1,7,1,7,1,7,1,7,5,7,164,8,7,10,
        7,12,7,167,9,7,1,7,1,7,1,8,1,8,1,8,1,8,5,8,175,8,8,10,8,12,8,178,
        9,8,1,8,1,8,1,8,0,1,6,9,0,2,4,6,8,10,12,14,16,0,3,1,0,3,8,1,0,9,
        11,1,0,12,13,202,0,21,1,0,0,0,2,40,1,0,0,0,4,42,1,0,0,0,6,58,1,0,
        0,0,8,77,1,0,0,0,10,100,1,0,0,0,12,157,1,0,0,0,14,159,1,0,0,0,16,
        170,1,0,0,0,18,20,3,2,1,0,19,18,1,0,0,0,20,23,1,0,0,0,21,19,1,0,
        0,0,21,22,1,0,0,0,22,24,1,0,0,0,23,21,1,0,0,0,24,25,5,0,0,1,25,1,
        1,0,0,0,26,28,3,4,2,0,27,29,5,1,0,0,28,27,1,0,0,0,28,29,1,0,0,0,
        29,41,1,0,0,0,30,32,3,6,3,0,31,33,5,1,0,0,32,31,1,0,0,0,32,33,1,
        0,0,0,33,41,1,0,0,0,34,36,3,10,5,0,35,37,5,1,0,0,36,35,1,0,0,0,36,
        37,1,0,0,0,37,41,1,0,0,0,38,41,3,12,6,0,39,41,3,8,4,0,40,26,1,0,
        0,0,40,30,1,0,0,0,40,34,1,0,0,0,40,38,1,0,0,0,40,39,1,0,0,0,41,3,
        1,0,0,0,42,43,5,26,0,0,43,44,5,2,0,0,44,45,3,6,3,0,45,5,1,0,0,0,
        46,47,6,3,-1,0,47,48,5,13,0,0,48,59,3,6,3,7,49,50,5,15,0,0,50,51,
        3,6,3,0,51,52,5,16,0,0,52,59,1,0,0,0,53,59,3,10,5,0,54,59,3,14,7,
        0,55,59,3,16,8,0,56,59,5,27,0,0,57,59,5,26,0,0,58,46,1,0,0,0,58,
        49,1,0,0,0,58,53,1,0,0,0,58,54,1,0,0,0,58,55,1,0,0,0,58,56,1,0,0,
        0,58,57,1,0,0,0,59,74,1,0,0,0,60,61,10,11,0,0,61,62,7,0,0,0,62,73,
        3,6,3,12,63,64,10,10,0,0,64,65,7,1,0,0,65,73,3,6,3,11,66,67,10,9,
        0,0,67,68,7,2,0,0,68,73,3,6,3,10,69,70,10,8,0,0,70,71,5,14,0,0,71,
        73,3,6,3,9,72,60,1,0,0,0,72,63,1,0,0,0,72,66,1,0,0,0,72,69,1,0,0,
        0,73,76,1,0,0,0,74,72,1,0,0,0,74,75,1,0,0,0,75,7,1,0,0,0,76,74,1,
        0,0,0,77,78,5,17,0,0,78,79,5,26,0,0,79,88,5,15,0,0,80,85,5,26,0,
        0,81,82,5,18,0,0,82,84,5,26,0,0,83,81,1,0,0,0,84,87,1,0,0,0,85,83,
        1,0,0,0,85,86,1,0,0,0,86,89,1,0,0,0,87,85,1,0,0,0,88,80,1,0,0,0,
        88,89,1,0,0,0,89,90,1,0,0,0,90,91,5,16,0,0,91,95,5,19,0,0,92,94,
        3,2,1,0,93,92,1,0,0,0,94,97,1,0,0,0,95,93,1,0,0,0,95,96,1,0,0,0,
        96,98,1,0,0,0,97,95,1,0,0,0,98,99,5,20,0,0,99,9,1,0,0,0,100,101,
        5,26,0,0,101,110,5,15,0,0,102,107,3,6,3,0,103,104,5,18,0,0,104,106,
        3,6,3,0,105,103,1,0,0,0,106,109,1,0,0,0,107,105,1,0,0,0,107,108,
        1,0,0,0,108,111,1,0,0,0,109,107,1,0,0,0,110,102,1,0,0,0,110,111,
        1,0,0,0,111,112,1,0,0,0,112,113,5,16,0,0,113,11,1,0,0,0,114,115,
        5,21,0,0,115,116,5,15,0,0,116,117,3,6,3,0,117,118,5,16,0,0,118,122,
        5,19,0,0,119,121,3,2,1,0,120,119,1,0,0,0,121,124,1,0,0,0,122,120,
        1,0,0,0,122,123,1,0,0,0,123,125,1,0,0,0,124,122,1,0,0,0,125,126,
        5,20,0,0,126,158,1,0,0,0,127,128,5,22,0,0,128,129,5,15,0,0,129,130,
        3,6,3,0,130,131,5,16,0,0,131,135,5,19,0,0,132,134,3,2,1,0,133,132,
        1,0,0,0,134,137,1,0,0,0,135,133,1,0,0,0,135,136,1,0,0,0,136,138,
        1,0,0,0,137,135,1,0,0,0,138,139,5,20,0,0,139,158,1,0,0,0,140,141,
        5,23,0,0,141,142,5,15,0,0,142,143,3,4,2,0,143,144,5,1,0,0,144,145,
        3,6,3,0,145,146,5,1,0,0,146,147,3,4,2,0,147,148,5,16,0,0,148,152,
        5,19,0,0,149,151,3,2,1,0,150,149,1,0,0,0,151,154,1,0,0,0,152,150,
        1,0,0,0,152,153,1,0,0,0,153,155,1,0,0,0,154,152,1,0,0,0,155,156,
        5,20,0,0,156,158,1,0,0,0,157,114,1,0,0,0,157,127,1,0,0,0,157,140,
        1,0,0,0,158,13,1,0,0,0,159,160,5,24,0,0,160,165,3,6,3,0,161,162,
        5,18,0,0,162,164,3,6,3,0,163,161,1,0,0,0,164,167,1,0,0,0,165,163,
        1,0,0,0,165,166,1,0,0,0,166,168,1,0,0,0,167,165,1,0,0,0,168,169,
        5,25,0,0,169,15,1,0,0,0,170,171,5,24,0,0,171,176,3,14,7,0,172,173,
        5,18,0,0,173,175,3,14,7,0,174,172,1,0,0,0,175,178,1,0,0,0,176,174,
        1,0,0,0,176,177,1,0,0,0,177,179,1,0,0,0,178,176,1,0,0,0,179,180,
        5,25,0,0,180,17,1,0,0,0,19,21,28,32,36,40,58,72,74,85,88,95,107,
        110,122,135,152,157,165,176
    ]

class NeuroMathLangParser ( Parser ):

    grammarFileName = "NeuroMathLang.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'='", "'>'", "'<'", "'>='", "'<='", 
                     "'=='", "'!='", "'*'", "'/'", "'%'", "'+'", "'-'", 
                     "'^'", "'('", "')'", "'funcion'", "','", "'{'", "'}'", 
                     "'if'", "'while'", "'for'", "'['", "']'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "ID", "NUMBER", "WS", "COMMENT" ]

    RULE_program = 0
    RULE_stat = 1
    RULE_assign = 2
    RULE_expr = 3
    RULE_funcDef = 4
    RULE_funcCall = 5
    RULE_control = 6
    RULE_list = 7
    RULE_matrix = 8

    ruleNames =  [ "program", "stat", "assign", "expr", "funcDef", "funcCall", 
                   "control", "list", "matrix" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    ID=26
    NUMBER=27
    WS=28
    COMMENT=29

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(NeuroMathLangParser.EOF, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.StatContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.StatContext,i)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = NeuroMathLangParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 232955904) != 0):
                self.state = 18
                self.stat()
                self.state = 23
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 24
            self.match(NeuroMathLangParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_stat

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExprStatContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprStat" ):
                listener.enterExprStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprStat" ):
                listener.exitExprStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprStat" ):
                return visitor.visitExprStat(self)
            else:
                return visitor.visitChildren(self)


    class AssignStatContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def assign(self):
            return self.getTypedRuleContext(NeuroMathLangParser.AssignContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignStat" ):
                listener.enterAssignStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignStat" ):
                listener.exitAssignStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignStat" ):
                return visitor.visitAssignStat(self)
            else:
                return visitor.visitChildren(self)


    class FuncCallStatContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def funcCall(self):
            return self.getTypedRuleContext(NeuroMathLangParser.FuncCallContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncCallStat" ):
                listener.enterFuncCallStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncCallStat" ):
                listener.exitFuncCallStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCallStat" ):
                return visitor.visitFuncCallStat(self)
            else:
                return visitor.visitChildren(self)


    class ControlStatContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def control(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ControlContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterControlStat" ):
                listener.enterControlStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitControlStat" ):
                listener.exitControlStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitControlStat" ):
                return visitor.visitControlStat(self)
            else:
                return visitor.visitChildren(self)


    class FuncDefStatContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def funcDef(self):
            return self.getTypedRuleContext(NeuroMathLangParser.FuncDefContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncDefStat" ):
                listener.enterFuncDefStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncDefStat" ):
                listener.exitFuncDefStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncDefStat" ):
                return visitor.visitFuncDefStat(self)
            else:
                return visitor.visitChildren(self)



    def stat(self):

        localctx = NeuroMathLangParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        self._la = 0 # Token type
        try:
            self.state = 40
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                localctx = NeuroMathLangParser.AssignStatContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 26
                self.assign()
                self.state = 28
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 27
                    self.match(NeuroMathLangParser.T__0)


                pass

            elif la_ == 2:
                localctx = NeuroMathLangParser.ExprStatContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 30
                self.expr(0)
                self.state = 32
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 31
                    self.match(NeuroMathLangParser.T__0)


                pass

            elif la_ == 3:
                localctx = NeuroMathLangParser.FuncCallStatContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 34
                self.funcCall()
                self.state = 36
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 35
                    self.match(NeuroMathLangParser.T__0)


                pass

            elif la_ == 4:
                localctx = NeuroMathLangParser.ControlStatContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 38
                self.control()
                pass

            elif la_ == 5:
                localctx = NeuroMathLangParser.FuncDefStatContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 39
                self.funcDef()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(NeuroMathLangParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign" ):
                listener.enterAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign" ):
                listener.exitAssign(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)




    def assign(self):

        localctx = NeuroMathLangParser.AssignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_assign)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            self.match(NeuroMathLangParser.ID)
            self.state = 43
            self.match(NeuroMathLangParser.T__1)
            self.state = 44
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class MulDivModContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulDivMod" ):
                listener.enterMulDivMod(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulDivMod" ):
                listener.exitMulDivMod(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulDivMod" ):
                return visitor.visitMulDivMod(self)
            else:
                return visitor.visitChildren(self)


    class VariableContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(NeuroMathLangParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable" ):
                return visitor.visitVariable(self)
            else:
                return visitor.visitChildren(self)


    class NumberContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(NeuroMathLangParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)


    class AddSubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddSub" ):
                listener.enterAddSub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddSub" ):
                listener.exitAddSub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddSub" ):
                return visitor.visitAddSub(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParens" ):
                listener.enterParens(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParens" ):
                listener.exitParens(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class UnaryMinusContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryMinus" ):
                listener.enterUnaryMinus(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryMinus" ):
                listener.exitUnaryMinus(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryMinus" ):
                return visitor.visitUnaryMinus(self)
            else:
                return visitor.visitChildren(self)


    class MatrixExprContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def matrix(self):
            return self.getTypedRuleContext(NeuroMathLangParser.MatrixContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMatrixExpr" ):
                listener.enterMatrixExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMatrixExpr" ):
                listener.exitMatrixExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMatrixExpr" ):
                return visitor.visitMatrixExpr(self)
            else:
                return visitor.visitChildren(self)


    class CompareContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompare" ):
                listener.enterCompare(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompare" ):
                listener.exitCompare(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompare" ):
                return visitor.visitCompare(self)
            else:
                return visitor.visitChildren(self)


    class ListExprContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def list_(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListExpr" ):
                listener.enterListExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListExpr" ):
                listener.exitListExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListExpr" ):
                return visitor.visitListExpr(self)
            else:
                return visitor.visitChildren(self)


    class PowerContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPower" ):
                listener.enterPower(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPower" ):
                listener.exitPower(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPower" ):
                return visitor.visitPower(self)
            else:
                return visitor.visitChildren(self)


    class FuncCallExprContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def funcCall(self):
            return self.getTypedRuleContext(NeuroMathLangParser.FuncCallContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncCallExpr" ):
                listener.enterFuncCallExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncCallExpr" ):
                listener.exitFuncCallExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCallExpr" ):
                return visitor.visitFuncCallExpr(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = NeuroMathLangParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 6
        self.enterRecursionRule(localctx, 6, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 58
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                localctx = NeuroMathLangParser.UnaryMinusContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 47
                self.match(NeuroMathLangParser.T__12)
                self.state = 48
                self.expr(7)
                pass

            elif la_ == 2:
                localctx = NeuroMathLangParser.ParensContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 49
                self.match(NeuroMathLangParser.T__14)
                self.state = 50
                self.expr(0)
                self.state = 51
                self.match(NeuroMathLangParser.T__15)
                pass

            elif la_ == 3:
                localctx = NeuroMathLangParser.FuncCallExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 53
                self.funcCall()
                pass

            elif la_ == 4:
                localctx = NeuroMathLangParser.ListExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 54
                self.list_()
                pass

            elif la_ == 5:
                localctx = NeuroMathLangParser.MatrixExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 55
                self.matrix()
                pass

            elif la_ == 6:
                localctx = NeuroMathLangParser.NumberContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 56
                self.match(NeuroMathLangParser.NUMBER)
                pass

            elif la_ == 7:
                localctx = NeuroMathLangParser.VariableContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 57
                self.match(NeuroMathLangParser.ID)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 74
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 72
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = NeuroMathLangParser.CompareContext(self, NeuroMathLangParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 60
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 61
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 504) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 62
                        self.expr(12)
                        pass

                    elif la_ == 2:
                        localctx = NeuroMathLangParser.MulDivModContext(self, NeuroMathLangParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 63
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 64
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 3584) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 65
                        self.expr(11)
                        pass

                    elif la_ == 3:
                        localctx = NeuroMathLangParser.AddSubContext(self, NeuroMathLangParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 66
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 67
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==12 or _la==13):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 68
                        self.expr(10)
                        pass

                    elif la_ == 4:
                        localctx = NeuroMathLangParser.PowerContext(self, NeuroMathLangParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 69
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 70
                        localctx.op = self.match(NeuroMathLangParser.T__13)
                        self.state = 71
                        self.expr(9)
                        pass

             
                self.state = 76
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FuncDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(NeuroMathLangParser.ID)
            else:
                return self.getToken(NeuroMathLangParser.ID, i)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.StatContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.StatContext,i)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_funcDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncDef" ):
                listener.enterFuncDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncDef" ):
                listener.exitFuncDef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncDef" ):
                return visitor.visitFuncDef(self)
            else:
                return visitor.visitChildren(self)




    def funcDef(self):

        localctx = NeuroMathLangParser.FuncDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_funcDef)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(NeuroMathLangParser.T__16)
            self.state = 78
            self.match(NeuroMathLangParser.ID)
            self.state = 79
            self.match(NeuroMathLangParser.T__14)
            self.state = 88
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 80
                self.match(NeuroMathLangParser.ID)
                self.state = 85
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 81
                    self.match(NeuroMathLangParser.T__17)
                    self.state = 82
                    self.match(NeuroMathLangParser.ID)
                    self.state = 87
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 90
            self.match(NeuroMathLangParser.T__15)
            self.state = 91
            self.match(NeuroMathLangParser.T__18)
            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 232955904) != 0):
                self.state = 92
                self.stat()
                self.state = 97
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 98
            self.match(NeuroMathLangParser.T__19)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(NeuroMathLangParser.ID, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_funcCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncCall" ):
                listener.enterFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncCall" ):
                listener.exitFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCall" ):
                return visitor.visitFuncCall(self)
            else:
                return visitor.visitChildren(self)




    def funcCall(self):

        localctx = NeuroMathLangParser.FuncCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_funcCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 100
            self.match(NeuroMathLangParser.ID)
            self.state = 101
            self.match(NeuroMathLangParser.T__14)
            self.state = 110
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 218144768) != 0):
                self.state = 102
                self.expr(0)
                self.state = 107
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 103
                    self.match(NeuroMathLangParser.T__17)
                    self.state = 104
                    self.expr(0)
                    self.state = 109
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 112
            self.match(NeuroMathLangParser.T__15)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ControlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_control

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class WhileControlContext(ControlContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ControlContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.StatContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.StatContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileControl" ):
                listener.enterWhileControl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileControl" ):
                listener.exitWhileControl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileControl" ):
                return visitor.visitWhileControl(self)
            else:
                return visitor.visitChildren(self)


    class ForControlContext(ControlContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ControlContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.AssignContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.AssignContext,i)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.StatContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.StatContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForControl" ):
                listener.enterForControl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForControl" ):
                listener.exitForControl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForControl" ):
                return visitor.visitForControl(self)
            else:
                return visitor.visitChildren(self)


    class IfControlContext(ControlContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a NeuroMathLangParser.ControlContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.StatContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.StatContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfControl" ):
                listener.enterIfControl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfControl" ):
                listener.exitIfControl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfControl" ):
                return visitor.visitIfControl(self)
            else:
                return visitor.visitChildren(self)



    def control(self):

        localctx = NeuroMathLangParser.ControlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_control)
        self._la = 0 # Token type
        try:
            self.state = 157
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                localctx = NeuroMathLangParser.IfControlContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 114
                self.match(NeuroMathLangParser.T__20)
                self.state = 115
                self.match(NeuroMathLangParser.T__14)
                self.state = 116
                self.expr(0)
                self.state = 117
                self.match(NeuroMathLangParser.T__15)
                self.state = 118
                self.match(NeuroMathLangParser.T__18)
                self.state = 122
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 232955904) != 0):
                    self.state = 119
                    self.stat()
                    self.state = 124
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 125
                self.match(NeuroMathLangParser.T__19)
                pass
            elif token in [22]:
                localctx = NeuroMathLangParser.WhileControlContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 127
                self.match(NeuroMathLangParser.T__21)
                self.state = 128
                self.match(NeuroMathLangParser.T__14)
                self.state = 129
                self.expr(0)
                self.state = 130
                self.match(NeuroMathLangParser.T__15)
                self.state = 131
                self.match(NeuroMathLangParser.T__18)
                self.state = 135
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 232955904) != 0):
                    self.state = 132
                    self.stat()
                    self.state = 137
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 138
                self.match(NeuroMathLangParser.T__19)
                pass
            elif token in [23]:
                localctx = NeuroMathLangParser.ForControlContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 140
                self.match(NeuroMathLangParser.T__22)
                self.state = 141
                self.match(NeuroMathLangParser.T__14)
                self.state = 142
                self.assign()
                self.state = 143
                self.match(NeuroMathLangParser.T__0)
                self.state = 144
                self.expr(0)
                self.state = 145
                self.match(NeuroMathLangParser.T__0)
                self.state = 146
                self.assign()
                self.state = 147
                self.match(NeuroMathLangParser.T__15)
                self.state = 148
                self.match(NeuroMathLangParser.T__18)
                self.state = 152
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 232955904) != 0):
                    self.state = 149
                    self.stat()
                    self.state = 154
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 155
                self.match(NeuroMathLangParser.T__19)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ExprContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ExprContext,i)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList" ):
                listener.enterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList" ):
                listener.exitList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitList" ):
                return visitor.visitList(self)
            else:
                return visitor.visitChildren(self)




    def list_(self):

        localctx = NeuroMathLangParser.ListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159
            self.match(NeuroMathLangParser.T__23)
            self.state = 160
            self.expr(0)
            self.state = 165
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==18:
                self.state = 161
                self.match(NeuroMathLangParser.T__17)
                self.state = 162
                self.expr(0)
                self.state = 167
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 168
            self.match(NeuroMathLangParser.T__24)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MatrixContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def list_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(NeuroMathLangParser.ListContext)
            else:
                return self.getTypedRuleContext(NeuroMathLangParser.ListContext,i)


        def getRuleIndex(self):
            return NeuroMathLangParser.RULE_matrix

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMatrix" ):
                listener.enterMatrix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMatrix" ):
                listener.exitMatrix(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMatrix" ):
                return visitor.visitMatrix(self)
            else:
                return visitor.visitChildren(self)




    def matrix(self):

        localctx = NeuroMathLangParser.MatrixContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_matrix)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.match(NeuroMathLangParser.T__23)
            self.state = 171
            self.list_()
            self.state = 176
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==18:
                self.state = 172
                self.match(NeuroMathLangParser.T__17)
                self.state = 173
                self.list_()
                self.state = 178
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 179
            self.match(NeuroMathLangParser.T__24)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[3] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 8)
         




