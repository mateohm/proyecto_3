def graficar(x, y):
    if len(x) != len(y):
        print("Error: Las listas x e y deben tener la misma longitud.")
        return

    max_y = max(y)
    min_y = min(y)
    escala = 20

    def escalar(valor):
        if max_y == min_y:
            return escala // 2
        return int((valor - min_y) / (max_y - min_y) * escala)

    print("\nGráfico ASCII de los datos:\n")
    for i in range(len(x)):
        espacio = ' ' * escalar(y[i])
        print(f"x={x[i]:>5} |{espacio}*")

    print("\nLeyenda: '*' representa la altura de y en escala 0–20\n")


def graficar_clusters(grupos):
    print("\nGráfico ASCII de Clusters (simplificado):\n")
    for i, grupo in enumerate(grupos):
        print(f"Cluster {i + 1}:")
        for punto in grupo:
            espacio = ' ' * int(sum(punto) * 2)
            print(f"{espacio}● {punto}")
        print()
    print("Leyenda: '●' representa un punto del cluster\n")
