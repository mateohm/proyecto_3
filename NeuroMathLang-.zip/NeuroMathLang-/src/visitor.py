from generated.NeuroMathLangVisitor import NeuroMathLangVisitor

class Context:
    def __init__(self):
        self.variables = {}

    def get(self, name):
        if name not in self.variables:
            raise Exception(f"Variable '{name}' no definida")
        return self.variables[name]

    def set(self, name, value):
        self.variables[name] = value

# Funciones matemáticas
def factorial(n):
    res = 1
    for i in range(2, n + 1):
        res *= i
    return res

def sin(x, terms=10):
    result = 0
    for n in range(terms):
        result += ((-1) ** n) * (x ** (2 * n + 1)) / factorial(2 * n + 1)
    return result

def cos(x, terms=10):
    result = 0
    for n in range(terms):
        result += ((-1) ** n) * (x ** (2 * n)) / factorial(2 * n)
    return result

def tan(x):
    c = cos(x)
    if c == 0:
        raise Exception("Tangente indefinida")
    return sin(x) / c

def regresion_lineal(x_vals, y_vals):
    n = len(x_vals)
    sum_x = sum(x_vals)
    sum_y = sum(y_vals)
    sum_x2 = sum([x ** 2 for x in x_vals])
    sum_xy = sum([x_vals[i] * y_vals[i] for i in range(n)])
    m = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
    b = (sum_y - m * sum_x) / n
    return {"m": m, "b": b}

def predecir(m, b, x_vals):
    return [m * x + b for x in x_vals]

def evaluar_objetivo(a, b, soluciones):
    resultados = []
    for x, y in soluciones:
        resultados.append((a * x + b * y, x, y))
    return max(resultados, key=lambda z: z[0])

def clustering(datos, k=2, iteraciones=10):
    centroides = datos[:k]
    for _ in range(iteraciones):
        grupos = [[] for _ in range(k)]
        for punto in datos:
            distancias = [sum((punto[i] - c[i]) ** 2 for i in range(len(punto))) for c in centroides]
            grupo = distancias.index(min(distancias))
            grupos[grupo].append(punto)
        for i in range(k):
            if grupos[i]:
                centroides[i] = [sum(p[j] for p in grupos[i]) / len(grupos[i]) for j in range(len(grupos[i][0]))]
    return grupos

def perceptron(datos, etiquetas, entrada, epocas=10, tasa=0.1):
    pesos = [0] * len(datos[0])
    bias = 0
    for _ in range(epocas):
        for i in range(len(datos)):
            activacion = sum([datos[i][j] * pesos[j] for j in range(len(pesos))]) + bias
            salida = 1 if activacion >= 0 else 0
            error = etiquetas[i] - salida
            for j in range(len(pesos)):
                pesos[j] += tasa * error * datos[i][j]
            bias += tasa * error
    resultados = []
    for x in entrada:
        activacion = sum([x[j] * pesos[j] for j in range(len(pesos))]) + bias
        resultados.append(1 if activacion >= 0 else 0)
    return resultados

# VISITOR PRINCIPAL
class Visitor(NeuroMathLangVisitor):
    def __init__(self):
        self.ctx = Context()

    def visitAssignStat(self, ctx):
        var_name = ctx.assign().ID().getText()
        value = self.visit(ctx.assign().expr())
        self.ctx.set(var_name, value)
        return value

    def visitExprStat(self, ctx):
        return self.visit(ctx.expr())

    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        return left + right if ctx.op.text == '+' else left - right

    def visitMulDivMod(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.text == '*':
            return left * right
        elif ctx.op.text == '/':
            return left / right
        else:
            return left % right

    def visitPower(self, ctx):
        return self.visit(ctx.expr(0)) ** self.visit(ctx.expr(1))

    def visitUnaryMinus(self, ctx):
        return -self.visit(ctx.expr())

    def visitParens(self, ctx):
        return self.visit(ctx.expr())

    def visitNumber(self, ctx):
        return float(ctx.getText())

    def visitVariable(self, ctx):
        return self.ctx.get(ctx.getText())

    def visitListExpr(self, ctx):
        return self.visit(ctx.list_())

    def visitList(self, ctx):
        return [self.visit(e) for e in ctx.expr()]

    def visitMatrixExpr(self, ctx):
        return self.visit(ctx.matrix())

    def visitMatrix(self, ctx):
        return [self.visit(lst) for lst in ctx.list_()]

    def visitFuncCallStat(self, ctx):
        return self.visit(ctx.funcCall())

    def visitFuncCall(self, ctx):
        if ctx.ID().getText() == "red_neuronal":
            entrada_raw = [self.visit(arg) for arg in ctx.expr()]
    
            # Asegurarse de que todos sean float
            entrada = []
            for item in entrada_raw:
                if isinstance(item, list):
                    entrada.extend(item)  # aplanar lista
                else:
                    entrada.append(float(item))

            red = MiniRedNeuronal(input_size=len(entrada))
            return red.forward(entrada)



        name = ctx.ID().getText()
        args = [self.visit(arg) for arg in ctx.expr()]
        
        if name == "sin":
            return sin(args[0])
        elif name == "cos":
            return cos(args[0])
        elif name == "tan":
            return tan(args[0])
        elif name == "regresion_lineal":
            return regresion_lineal(args[0], args[1])
        elif name == "predecir":
            return predecir(args[0], args[1], args[2])
        elif name == "evaluar_z":
            return evaluar_objetivo(args[0], args[1], args[2])
        elif name == "clustering":
            return clustering(args[0], int(args[1]), int(args[2]) if len(args) > 2 else 10)
        elif name == "clasificar":
            return perceptron(args[0], args[1], args[2])
        elif name == "imprimir":
            for arg in args:
                print(arg)
            return 0
        elif name == "graficar":
            from lib.graficacion import graficar
            graficar(args[0], args[1])
            return 0
        elif name == "graficar_clusters":
            from lib.graficacion import graficar_clusters
            graficar_clusters(args[0])
            return 0
        else:
            raise Exception(f"Función '{name}' no implementada")

    def visitIfControl(self, ctx):
        if self.visit(ctx.expr()):
            for stmt in ctx.stat():
                self.visit(stmt)

    def visitWhileControl(self, ctx):
        while self.visit(ctx.expr()):
            for stmt in ctx.stat():
                self.visit(stmt)


import math
import random

class MiniRedNeuronal:
    def __init__(self, input_size):
        self.W = [random.uniform(-1, 1) for _ in range(input_size)]
        self.b = random.uniform(-1, 1)

    def sigmoid(self, x):
        return 1 / (1 + math.exp(-x))

    def forward(self, x):
        suma = sum(wi * xi for wi, xi in zip(self.W, x)) + self.b
        return [round(self.sigmoid(suma), 4)]
