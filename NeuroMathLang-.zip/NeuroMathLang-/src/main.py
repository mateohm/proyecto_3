import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from antlr4 import *
from generated.NeuroMathLangLexer import NeuroMathLangLexer
from generated.NeuroMathLangParser import NeuroMathLangParser
from visitor import Visitor

def interpretar_codigo(codigo):
    input_stream = InputStream(codigo)
    lexer = NeuroMathLangLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = NeuroMathLangParser(token_stream)
    tree = parser.program()
    visitor = Visitor()
    visitor.visit(tree)

def main():
    while True:
        print("\n1. Trigonometría")
        print("2. Regresión lineal")
        print("3. Predicción con regresión")
        print("4. Programación lineal")
        print("5. Clustering")
        print("6. Ejecutar archivo .nml")
        print("7. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            angulo = input("Ingrese el ángulo (en radianes): ")
            codigo = f"""
a = {angulo}
imprimir(sin(a))
imprimir(cos(a))
imprimir(tan(a))
"""
            interpretar_codigo(codigo)

        elif opcion == '2':
            x = input("Ingrese los valores de X separados por espacio: ").split()
            y = input("Ingrese los valores de Y separados por espacio: ").split()
            codigo = f"""
x = [{','.join(x)}]
y = [{','.join(y)}]
modelo = regresion_lineal(x, y)
imprimir(modelo)
graficar(x, y)
"""
            interpretar_codigo(codigo)

        elif opcion == '3':
            m = input("Ingrese el valor de m: ")
            b = input("Ingrese el valor de b: ")
            x = input("Ingrese los valores de X a predecir separados por espacio: ").split()
            codigo = f"""
m = {m}
b = {b}
x = [{','.join(x)}]
pred = predecir(m, b, x)
imprimir(pred)
graficar(x, pred)
"""
            interpretar_codigo(codigo)

        elif opcion == '4':
            a = input("Coeficiente a (de x): ")
            b = input("Coeficiente b (de y): ")
            try:
                n = int(input("¿Cuántas soluciones desea ingresar?: "))
            except ValueError:
                print("Debe ingresar un número.")
                continue
            puntos = []
            for i in range(n):
                try:
                    x, y = input(f"Solución {i+1} (x y): ").split()
                    puntos.append(f"({x},{y})")
                except ValueError:
                    print("Entrada inválida. Debe ingresar dos valores.")
                    break
            else:
                x_vals = [p.split(',')[0][1:] for p in puntos]
                y_vals = [p.split(',')[1][:-1] for p in puntos]
                codigo = f"""
soluciones = [{','.join(puntos)}]
resultado = evaluar_z({a}, {b}, soluciones)
imprimir(resultado)
graficar([{','.join(x_vals)}], [{','.join(y_vals)}])
"""
                interpretar_codigo(codigo)

        elif opcion == '5':
            datos = []
            try:
                n = int(input("¿Cuántos puntos desea ingresar?: "))
                for i in range(n):
                    punto = input(f"Punto {i+1} (x y): ").split()
                    datos.append(f"[{','.join(punto)}]")
                k = input("Número de clusters: ")
                it = input("Número de iteraciones: ")
                codigo = f"""
datos = [{','.join(datos)}]
grupos = clustering(datos, {k}, {it})
imprimir(grupos)
graficar_clusters(grupos)
"""
                interpretar_codigo(codigo)
            except Exception as e:
                print("Error en entrada:", e)

        elif opcion == '6':
            ruta = input("Ingrese la ruta del archivo .nml: ")
            try:
                with open(ruta, 'r') as archivo:
                    codigo = archivo.read()
                    interpretar_codigo(codigo)
            except FileNotFoundError:
                print("Archivo no encontrado. Verifique la ruta.")
            except Exception as e:
                print("Error al leer el archivo:", e)

        elif opcion == '7':
            break
        else:
            print("Opción inválida")

if __name__ == "__main__":
    main()
